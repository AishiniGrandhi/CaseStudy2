package package_1;

interface BankOperations {
    void deposit(double amount);
    void withdraw(double amount);
    void displayAccountInfo();
}

