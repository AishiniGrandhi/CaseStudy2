package package_1;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
		System.out.println("<<<<<>>>>>");
	}

}
